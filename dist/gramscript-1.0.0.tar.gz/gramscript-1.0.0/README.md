# ggramscript.py
Powerful, MTProto API framework in Python for users and bots
